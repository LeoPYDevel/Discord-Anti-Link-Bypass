# Discord anti-link bypass
## Download and setup:
### - Download [Node.js](https://nodejs.org/en)
### - execute `start.bat` file

## Usage:
> [!NOTE]
> ### Enter your link, that can be entered in two ways, example: <br/> `https://sanago.xyz` or `sanago.xyz`
<img title="a title" alt="Alt text" src="https://media.discordapp.net/attachments/1128674562259824651/1243386065310580806/image.png?ex=66514902&is=664ff782&hm=c237a13bce09be82d4c2932431776fe6dea5858132680980895127f2fbc74213&=&format=webp">

## Description:
### Usually, when you send a link on a discord server, bots or various protections prevent you from sending, for example:
<img title="first image" alt="Alt text" src="https://media.discordapp.net/attachments/1128674562259824651/1243376914484301985/image.png?ex=6651407d&is=664feefd&hm=5634fbddcc8e6f406199c4da1fc339333233b8e4257a0414b5eefa1b2b8faa28&=&format=webp">

### By using **discord link bypasser** the result looks like this:
<img title="second image" alt="Alt text" src="https://media.discordapp.net/attachments/1128674562259824651/1243376241281863781/image.png?ex=66513fdc&is=664fee5c&hm=0afc406e68da6d4840ed36860fc501ae81c41647f01eaabb7c0f18e4656a6d41&=&format=webp">

> [!CAUTION]
> For your use of this app, if you get mute/ban from any discord server, I am not responsible.
